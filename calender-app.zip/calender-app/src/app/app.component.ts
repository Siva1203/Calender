import { Component,OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'calender-app';
  country;
  year;
  holidays=[];
 countries=[];
 total;
  constructor(
    private http: HttpClient
  ) {}
  ngOnInit() {
   /* var api_key ="2616c496050a60c3ed0fb2e7ce3002e49992e32c";
    var url1= "https://calendarific.com/api/v2/countries?&api_key="+api_key;
    this.http.get(url1).subscribe((data: any[])=>{
      this.countries= data.response.countries;
      console.dir(this.countries);
    });*/
 }
  getHolidays(){
    console.log("Received inputs: "+this.country + ", "+this.year);
    var api_key ="2616c496050a60c3ed0fb2e7ce3002e49992e32c";
    var url= "https://calendarific.com/api/v2/holidays?&api_key="+api_key+"&country="+this.country+"&year="+this.year;
    var data1 = this.http.get(url).subscribe((data: any[])=>{
      this.holidays= data.response.holidays;
      console.dir(this.holidays);
      this.total= this.holidays.length;
    });
  }
}
